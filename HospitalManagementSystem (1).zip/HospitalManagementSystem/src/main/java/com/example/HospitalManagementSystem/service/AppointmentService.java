package com.example.HospitalManagementSystem.service;


import com.example.HospitalManagementSystem.DTO.AppointmentDTO;

public interface AppointmentService {

	String addAppointment(AppointmentDTO AppointmentDTO);
}
